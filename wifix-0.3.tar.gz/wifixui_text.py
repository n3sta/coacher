#!/usr/bin/python
# Author: Buran Ayuthia (the.ayuthias@gmail.com)
# Author: bmartin (blakecmartin@gmail.com)
# Author: Drew Johnson (https://launchpad.net/~nuboon2age)

"""
This file is part of WiFix.

WiFix is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

WiFix is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import wifixui

import os
import sys

import messages
import platforms
import pm
import threading
import commands
import webbrowser

class TextUI(wifixui.WifixUI):

    def build_driver_options_array(self, driver_details_set):
        print "TODO implement <wifix text>.build_driver_options_radiobutton_array"

    def check_programs(self):
        return self.program_exists("echo") and self.program_exists("grep") and self.program_exists("id") and self.program_exists("lshw") and self.program_exists("lspci") and self.program_exists("lsusb") and self.program_exists("sed")

    def close_application(self, widget):
        print "TODO implement <wifix text>.close_application"

    def get_progress_meter(self):
        return pm.ProgressMonitor()

    def run_installer(self, widget):
        print "TODO implement <wifix text>.run_installer"

    def submit_card_data(self, data=None):
        print "TODO implement <wifix text>.submit_card_data"

    def start(self, driver_options_array):
        print "TODO implement <wifix text>.start"

    def sudo(self, title, command):
        print "TODO implement <wifix text>.sudo"

    def use_command(self, radiobutton, val):
        print "TODO implement <wifix text>.use_command"

    def __init__(self, platformd):
        print "Text interface not yet implemented, please use gtk nterface"
        sys.exit(0) # Remove this line when implementing text interface.
