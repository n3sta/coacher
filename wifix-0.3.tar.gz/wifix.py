#!/usr/bin/python
# Author: Buran Ayuthia (the.ayuthias@gmail.com)
# Author: bmartin (blakecmartin@gmail.com)
# Author: Samuel A. Dieck (https://launchpad.net/~sam-dieck)
# Author: Drew Johnson (https://launchpad.net/~nuboon2age)

"""
This file is part of WiFix.

WiFix is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

WiFix is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import sys

import messages
import platforms

def show_usage():
    print messages.usage 
    sys.exit()

def check_sanity(platform, ui):
    # ensure the program isn't being run as root
    if platform.is_root():
        platform.message(messages.err_root)
        return False
    # ensure all necessary programs for the UI exist
    if not ui.check_programs():
        platform.message(messages.err_programs)
        return False

    return True

def display_privacy_notice(platform):
    if not platform.message_yesno(messages.privacy()):
        sys.exit()

def get_platform():
    if sys.platform.startswith("linux"):
        return platforms.PlatformLinux()
    else:
        print "The " + sys.platform + " platform is not supported by WiFix."
        sys.exit();

def get_ui():
    try:
        import wifixui_gtk
        ui = wifixui_gtk.GraphicalUI(platform)
        # perform checks to ensure the program can work properly
        if check_sanity(platform, ui):
            return ui
    except Exception, detail:
        print "Unable to use GTK interface:", detail

    try:
        import wifixui_qt
        ui = wifixui_qt.GraphicalUI(platform)
        # perform checks to ensure the program can work properly
        if check_sanity(platform, ui):
            return ui
    except Exception, detail:
        print "Unable to use Qt interface:", detail

    try:
        import wifixui_text
        ui = wifixui_text.UI(platform)
        # perform checks to ensure the program can work properly
        if check_sanity(platform, ui):
            return ui
    except Exception, detail:
        print "Unable to use text interface:", detail

    raise Exception("No UI available.")

# make sure we have an implementation for the given platform
platform = get_platform()

ui = None

# process command-line parameters
del sys.argv[0]

while len(sys.argv) > 0:
    arg=sys.argv[0]
    del sys.argv[0]
    if arg == "--help":
        show_usage()
    elif arg == "--gtk":
        import wifixui_gtk
        ui = wifixui_gtk.GraphicalUI(platform)
    elif arg == "--qt":
        import wifixui_qt
        ui = wifixui_qt.GraphicalUI(platform)
    elif arg == "--text":
        import wifixui_text
        ui = wifixui_text.TextUI(platform)
    else:
        print "Invalid parameter:", arg
        show_usage()

# figure out which UI we're going to use
if not ui:
    ui = get_ui()
else:
    if not check_sanity(platform, ui):
        raise Exception("Unable to use desired interface.")
display_privacy_notice(platform)

#######################################################################
### now that the platform and UI have been determined, we can begin ###
#######################################################################

import commands
import messages
#import webbrowser

driver_details = platform.get_devices(ui.get_progress_meter())
driver = ui.build_driver_options_array(driver_details)

if not driver:
    debug_info = platform.get_debug_info(ui.get_progress_meter())
    platform.message(messages.submitted + debug_info)
    sys.exit()
 
ui.start(driver)
