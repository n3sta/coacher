#!/bin/python
# Author: bmartin (blakecmartin@gmail.com)
# Author: Samuel A. Dieck (https://launchpad.net/~sam-dieck)

"""
This file is part of WiFix.

WiFix is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

WiFix is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

err_root = "Please run the installer without root priviledges."

submitted = "Wifix was unable to match a wireless device on this computer with any currently in the Wifix communitys Driver Database.\n\nThe Wifix Driver Database is a work in progress being built with the help of feedback from people like you. To help improve the database for everyone, please copy and paste the following information into an e-mail to wifix@wifix.thescoundrels.net:\n\n"

no_driver = "No driver information found on database.\nGathering debugging info"

usage = "USAGE:\twifix [ ARGS ]\n\nARGS:\n\t--help\tShow this usage\n\t--gtk\tUse GTK interface\n\t--qt\tUse QT interface\n\t--text\tUse text interface\n"
err_programs="A necessary program was not found. Make sure all necessary programs are installed in your system before continuing.\n"

def privacy():
    return __read_file('./messages/privacy')

def submission():
    return __read_file('./messages/submission')

def __read_file(file):
    f = open(file, 'r')
    contents = f.read()
    f.close()
    return contents
