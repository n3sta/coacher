#!/usr/bin/python
# Author: Buran Ayuthia (the.ayuthias@gmail.com)
# Author: bmartin (blakecmartin@gmail.com)
# Author: Drew Johnson (https://launchpad.net/~nuboon2age)

"""
This file is part of WiFix.

WiFix is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

WiFix is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import pm
import wifixui

import gtk

class GraphicalUI(wifixui.WifixUI):

    def build_driver_options_array(self, driver_details_set):
        driver_options_array = []
        curr_driver_radiobutton = gtk.RadioButton(None, "")
        for driver_option_detail in driver_details_set:
            label = driver_option_detail['label']
            driver = driver_option_detail['driver']
            arguments = driver_option_detail['arguments']
            if arguments.find(' -inf ') != -1:
                driver_type='Windows/NDIS'
            else:
                driver_type='compiled from source'
            install_msg = label + '\nDriver: ' + driver + ' (' + driver_type + ')'
            driver_option = gtk.RadioButton(curr_driver_radiobutton, install_msg)
            driver_option.connect("toggled", self.use_command, self.sudo("Run installer", self.platform.get_installer_command(arguments)))
            driver_options_array.append(driver_option)
        return driver_options_array

    def check_programs(self):
        return self.program_exists("echo") and self.program_exists("gksudo") and self.program_exists("grep") and self.program_exists("id") and self.program_exists("lshw") and self.program_exists("lspci") and self.program_exists("lsusb") and self.program_exists("sed") and self.program_exists("zenity")

    def close_application(self, widget):
        gtk.main_quit()

    def get_progress_meter(self):
        return pm.ProgressMonitor()

    def run_installer(self, widget):
        self.platform.execute(self.perform)
        self.close_application(widget)

    def submit_card_data(self, data=None):
        print "TODO implement the <wifix gtk version>.submit_card_data"

    def sudo(self, title, command):
        return "gksudo --message '" + title + "' '" + command + "'"

    def start(self, driver_option_array):
        for driver_option in driver_option_array:
            self.vbox.pack_start(driver_option, False, True, 0)
            driver_option.show()

        driver_option_array[0].set_active(True)
        self.textbuffer.set_text("Welcome to WiFix!!!!")
        separator = gtk.HSeparator()
        self.box1.pack_start(separator, False, True, 0)
        separator.show()

        self.box2 = gtk.VBox(False, 10)
        self.box2.set_border_width(10)
        self.box1.pack_start(self.box2, False, True, 0)
        self.box2.show()

        button = gtk.Button("Install")
        button.connect("clicked", self.run_installer)
        self.box2.pack_start(button, True, True, 0)
        button.set_flags(gtk.CAN_DEFAULT)
        button.grab_default()
        button.show()
        self.window.show()
        gtk.main()

    def use_command(self, driver_option, val):
        if driver_option.get_active():
            self.perform = val

    def __init__(self, platform):
        self.platform = platform
        self.device_info=''
        self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
        self.window.set_resizable(True)
        self.window.connect("destroy", self.close_application)
        self.window.set_title("WiFix Wireless Driver Installer")
        self.window.set_border_width(0)

        self.box1 = gtk.VBox(False, 0)
        self.window.add(self.box1)
        self.box1.show()

        self.box2 = gtk.VBox(False, 10)
        self.box2.set_border_width(10)
        self.box1.pack_start(self.box2, True, True, 0)
        self.box2.show()

        sw = gtk.ScrolledWindow()
        sw.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        textview = gtk.TextView()
        textview.set_editable(False)
        textview.set_cursor_visible(False)
        textview.set_wrap_mode(gtk.WRAP_WORD)

        self.textbuffer = textview.get_buffer()
        sw.add(textview)
        sw.show()
        textview.show()

        self.box2.pack_start(sw)

        hbox = gtk.HButtonBox()
        self.box2.pack_start(hbox, False, False, 0)
        hbox.show()

        self.vbox = gtk.VBox()
        self.vbox.show()
        hbox.pack_start(self.vbox, False, False, 0)
