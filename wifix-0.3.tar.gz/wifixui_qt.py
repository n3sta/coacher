#!/usr/bin/python
# Author: Buran Ayuthia (the.ayuthias@gmail.com)
# Author: bmartin (blakecmartin@gmail.com)
# Author: Samuel A. Dieck (https://launchpad.net/~sam-dieck)
# Author: Drew Johnson (https://launchpad.net/~nuboon2age)

"""
This file is part of WiFix.

WiFix is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

WiFix is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from PyQt4.QtCore import SIGNAL, SLOT
from PyQt4.QtGui import QApplication, QWidget, QTextEdit, QGridLayout, QPushButton, QRadioButton
import wifixui

import os
import sys

import messages
import platforms
import pm
import threading
import commands
import webbrowser

global app
app = QApplication(sys.argv)

class GraphicalUI(wifixui.WifixUI, QWidget):

    def build_driver_options_array(self, driver_details_set):
        driver_options_array = []
        for driver_option_detail in driver_details_set:
                label = driver_option_detail['label']
                driver = driver_option_detail['driver']
                arguments = driver_option_detail['arguments']
                driver_type='compiled from source'
                if arguments.find(' -inf ') != -1:
                        driver_type='Windows/NDIS'
                install_msg = label + '\nDriver: ' + driver + ' (' + driver_type + ')'
                driver_option = QRadioButton(install_msg, self)
                self.arg_list = self.platform.get_installer_command(arguments)
#                self.arg_list.append(driver_options_array_button)
                driver_option.connect(driver_option, SIGNAL("toggled(bool)"), self.use_command)
                driver_options_array.append(driver_option)
        return driver_options_array

    def check_programs(self):
        return self.program_exists("echo") and self.program_exists("grep") and self.program_exists("id") and (self.program_exists("kdesu") or self.program_exists("kdesudo")) and self.program_exists("lshw") and self.program_exists("lspci") and self.program_exists("lsusb") and self.program_exists("sed") and self.program_exists("zenity")

    def close_application(self):
        self.close()

    def get_progress_meter(self):
        return pm.ProgressMonitor()

    def run_installer(self):
        self.platform.execute(self.perform)
        self.close_application()

    def start(self, driver_options_array):
        row = 0
        self.MainLayout.setSpacing(10)
        self.MainLayout.addWidget(self.TextMsg, row, 0)
        row += 1
        for driver_option in driver_options_array:
            self.MainLayout.addWidget(driver_option, row, 0)
            driver_options_array_button.show()
            row += 1
        driver_options_array[0].setChecked(True)

        self.Button = QPushButton("Install", self)
        self.Button.connect(self.Button, SIGNAL("clicked()"), self.run_installer)
        self.MainLayout.addWidget(self.Button, row, 0)

        self.show()
        sys.exit(app.exec_())

    def submit_card_data(self, data=None):
        print "TODO implement the <wifix qt version>.submit_card_data"

    def sudo(self, title, command):
	if (self.program_exists ("kdesu")):
	    return "kdesu -c '" + command + "' --caption '" + title + "'"
	else: #kdesudo instead of kdesu
            return "kdesudo -c '" + command + "' --caption '" + title + "'"

    def use_command(self):
        val = self.arg_list
        self.perform = self.sudo("Run installer", val)

    def __init__(self, platform):
	print "QT not yet implemented, please use gtk interface"
	sys.exit (0);
        self.platform = platform
        QWidget.__init__(self)
        
        self.device_info = ''

        self.setWindowTitle("WiFix Wireless Driver Installer")
 
        self.MainLayout = QGridLayout(self)

        self.TextMsg = QTextEdit(self)
        self.TextMsg.setReadOnly(True)
        self.TextMsg.setText("Welcome to WiFix!!!!")
