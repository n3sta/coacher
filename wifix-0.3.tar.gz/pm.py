#!/usr/bin/python
# Author: bmartin (blakecmartin@gmail.com)

"""
This file is part of WiFix.

WiFix is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

WiFix is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import subprocess

class ProgressMonitor():
    def start(self, title, message):
        """
        Causes the progress monitor to pulsate.
        """

        self.p1 = subprocess.Popen(["/bin/cat", "/dev/zero"], stdout=subprocess.PIPE)
        self.p2 = subprocess.Popen(["zenity", "--progress", "--pulsate", "--text=" + message, "--title=" + title], stdin=self.p1.stdout, stdout=subprocess.PIPE)
        self.pid1 = self.p1.pid
        self.pid2 = self.p2.pid

    def stop(self):
        """
        Causes the progress monitor to disappear.
        """

        # kill the thread that feeds the pipe into zenity
        os.kill(self.pid1, 1)
        # kill the zenity thread
        os.kill(self.pid2, 1)
        # wait for the threads to finish
        self.p1.wait()
        self.p2.wait()
