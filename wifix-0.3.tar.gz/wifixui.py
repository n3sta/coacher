#!/usr/bin/python
# Author: bmartin (blakecmartin@gmail.com)
# Author: Samuel A. Dieck (https://launchpad.net/~sam-dieck)
"""
This file is part of WiFix.

WiFix is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

WiFix is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os

class WifixUI():
    def check_dependencies(self):
        """
        Ensures that all dependent programs exist.
        """

        raise NotImplementedError

    def check_programs(self):
        """
        Returns True if all of the necessary programs are present, false
        otherwise.
        """

        raise NotImplementedError

    def get_dependencies(self):
        """
        Retrieves a list of programs that must exist in order to use this UI.
        """

    def get_progress_meter(self):
        """
        Retrieves a progress meter for the UI.
        """

        raise NotImplementedError

    def program_exists(self, program):
        """
        Returns True if the given program exists, false otherwise.
        """

        if os.system("which " + program + " > /dev/null"):
	    print program + ": program not found."
            return False  
        return True

    def sudo(self, title, command):
        """
        Returns a command string that, if executed, will perform the given
        command with elevated provileges.
        """

        raise NotImplementedError

    def start(self, options_list):
        """
        Begins execution of the UI.
        """

        raise NotImplementedError
